// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xpredictor.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPredictor_CfgInitialize(XPredictor *InstancePtr, XPredictor_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPredictor_Start(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL) & 0x80;
    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPredictor_IsDone(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPredictor_IsIdle(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPredictor_IsReady(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPredictor_EnableAutoRestart(XPredictor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XPredictor_DisableAutoRestart(XPredictor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_AP_CTRL, 0);
}

void XPredictor_Set_sample(XPredictor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_SAMPLE_DATA, Data);
}

u32 XPredictor_Get_sample(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_SAMPLE_DATA);
    return Data;
}

void XPredictor_Set_neighboor(XPredictor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_NEIGHBOOR_DATA, Data);
}

u32 XPredictor_Get_neighboor(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_NEIGHBOOR_DATA);
    return Data;
}

void XPredictor_Set_t(XPredictor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_T_DATA, Data);
}

u32 XPredictor_Get_t(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_T_DATA);
    return Data;
}

void XPredictor_Set_z(XPredictor *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_Z_DATA, Data);
}

u32 XPredictor_Get_z(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_Z_DATA);
    return Data;
}

u32 XPredictor_Get_out_compressor(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_OUT_COMPRESSOR_DATA);
    return Data;
}

u32 XPredictor_Get_out_compressor_vld(XPredictor *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_OUT_COMPRESSOR_CTRL);
    return Data & 0x1;
}

void XPredictor_InterruptGlobalEnable(XPredictor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_GIE, 1);
}

void XPredictor_InterruptGlobalDisable(XPredictor *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_GIE, 0);
}

void XPredictor_InterruptEnable(XPredictor *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_IER);
    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_IER, Register | Mask);
}

void XPredictor_InterruptDisable(XPredictor *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_IER);
    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_IER, Register & (~Mask));
}

void XPredictor_InterruptClear(XPredictor *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredictor_WriteReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_ISR, Mask);
}

u32 XPredictor_InterruptGetEnabled(XPredictor *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_IER);
}

u32 XPredictor_InterruptGetStatus(XPredictor *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredictor_ReadReg(InstancePtr->Control_BaseAddress, XPREDICTOR_CONTROL_ADDR_ISR);
}

